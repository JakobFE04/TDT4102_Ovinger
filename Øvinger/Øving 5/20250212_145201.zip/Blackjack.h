#pragma once
#include "CardDeck.h"

// Her kan du lage dine funksjons- og klassedeklarasjoner for å lage blackjack
