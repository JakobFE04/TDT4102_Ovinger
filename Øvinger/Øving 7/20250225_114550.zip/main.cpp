#include <iostream>
#include "DynamicMemory.h"
#include "Matrix.h"
#include "Dummy.h"

int main() {
	/*Matrix A{4};
	std::cout << A.get(2,2) << std::endl;
	A.set(2,2,3);
	std::cout << A.get(2,2) << std::endl;
	Matrix B{2,3};
	std::cout << B.get(2,2) << std::endl;
	std::cout << A << std::endl;
	A = B;
	Matrix C{A};
	std::cout << C.get(1,2) << std::endl;
	std::cout << C.getRows() << std::endl;
	std::cout << C << std::endl;*/
	//dummyTest();
	//std::cout<<"A"<<std::endl;
	testMatrix();
	return 0;
} 