#pragma once
#include "utilities.h"
#include "std_lib_facilities.h"
#include "mastermind.h"

void testCallByValue();
void testCallByReference();
void testString();